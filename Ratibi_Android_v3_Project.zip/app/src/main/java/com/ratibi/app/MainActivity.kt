package com.ratibi.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import java.security.MessageDigest
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.NumberFormat
import java.util.Locale

data class Tx(val id: Long, val title: String, val amount: Long, val type: String, val date: String)
data class Record(val id: Long, val title: String, val amount: Long, val extra: Long, val date: String, val status: String)

class DBHelper(a: Activity) : SQLiteOpenHelper(a, "ratibi.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount INTEGER, type TEXT, date TEXT)")
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT)")
        db.execSQL("CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT, person TEXT, amount INTEGER, kind TEXT, note TEXT, date TEXT)")
        db.execSQL("CREATE TABLE bills(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount INTEGER, due TEXT, paid INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE savings(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, target INTEGER, saved INTEGER DEFAULT 0)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS debts(id INTEGER PRIMARY KEY AUTOINCREMENT, person TEXT, amount INTEGER, kind TEXT, note TEXT, date TEXT)")
            db.execSQL("CREATE TABLE IF NOT EXISTS bills(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount INTEGER, due TEXT, paid INTEGER DEFAULT 0)")
            db.execSQL("CREATE TABLE IF NOT EXISTS savings(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, target INTEGER, saved INTEGER DEFAULT 0)")
        }
    }
    fun addTx(title: String, amount: Long, type: String) {
        writableDatabase.execSQL("INSERT INTO entries(title,amount,type,date) VALUES(?,?,?,date('now','localtime'))", arrayOf(title, amount, type))
    }
    fun transactions(): List<Tx> {
        val out = mutableListOf<Tx>()
        readableDatabase.rawQuery("SELECT id,title,amount,type,date FROM entries ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(Tx(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3), c.getString(4)))
        }
        return out
    }
    fun deleteTx(id: Long) { writableDatabase.delete("entries", "id=?", arrayOf(id.toString())) }
    fun setSalary(v: Long) { writableDatabase.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES('salary',?)", arrayOf(v.toString())) }
    fun salary(): Long {
        val c = readableDatabase.rawQuery("SELECT v FROM settings WHERE k='salary'", null)
        val v = if (c.moveToFirst()) c.getString(0).toLongOrNull() ?: 0L else 0L
        c.close(); return v
    }
    fun addDebt(person: String, amount: Long, kind: String, note: String) {
        writableDatabase.execSQL("INSERT INTO debts(person,amount,kind,note,date) VALUES(?,?,?,?,date('now','localtime'))", arrayOf(person, amount, kind, note))
    }
    fun debts(): List<Record> {
        val out = mutableListOf<Record>()
        readableDatabase.rawQuery("SELECT id,person,amount,0,date,kind FROM debts ORDER BY id DESC", null).use { c ->
            while(c.moveToNext()) out.add(Record(c.getLong(0),c.getString(1),c.getLong(2),0,c.getString(4),c.getString(5)))
        }; return out
    }
    fun deleteDebt(id: Long) { writableDatabase.delete("debts","id=?",arrayOf(id.toString())) }
    fun addBill(title: String, amount: Long, due: String) {
        writableDatabase.execSQL("INSERT INTO bills(title,amount,due,paid) VALUES(?,?,?,0)", arrayOf(title,amount,due))
    }
    fun bills(): List<Record> {
        val out= mutableListOf<Record>()
        readableDatabase.rawQuery("SELECT id,title,amount,0,due,paid FROM bills ORDER BY paid,due",null).use { c ->
            while(c.moveToNext()) out.add(Record(c.getLong(0),c.getString(1),c.getLong(2),0,c.getString(4),if(c.getInt(5)==1)"paid" else "unpaid"))
        }; return out
    }
    fun toggleBill(id: Long, paid: Boolean) { writableDatabase.execSQL("UPDATE bills SET paid=? WHERE id=?", arrayOf(if(paid)1 else 0,id)) }
    fun deleteBill(id: Long) { writableDatabase.delete("bills","id=?",arrayOf(id.toString())) }
    fun addGoal(title: String, target: Long) { writableDatabase.execSQL("INSERT INTO savings(title,target,saved) VALUES(?,?,0)",arrayOf(title,target)) }
    fun goals(): List<Record> {
        val out= mutableListOf<Record>()
        readableDatabase.rawQuery("SELECT id,title,target,saved,'', 'goal' FROM savings ORDER BY id DESC",null).use { c ->
            while(c.moveToNext()) out.add(Record(c.getLong(0),c.getString(1),c.getLong(2),c.getLong(3),"","goal"))
        }; return out
    }
    fun updateGoal(id: Long, saved: Long) { writableDatabase.execSQL("UPDATE savings SET saved=? WHERE id=?",arrayOf(saved,id)) }
    fun deleteGoal(id: Long) { writableDatabase.delete("savings","id=?",arrayOf(id.toString())) }
    fun monthTotals(offset: Int = 0): Pair<Long,Long> {
        val c=readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END),0), COALESCE(SUM(CASE WHEN type='income' THEN amount ELSE 0 END),0) FROM entries WHERE substr(date,1,7)=strftime('%Y-%m','now','localtime',?)",
            arrayOf(if(offset == 0) "0 months" else "$offset months"))
        c.moveToFirst(); val p=Pair(c.getLong(0),c.getLong(1)); c.close(); return p
    }
}

class MainActivity : Activity() {
    private lateinit var db: DBHelper
    private val CREATE_BACKUP = 701
    private val RESTORE_BACKUP = 702
    private val EXPORT_CSV = 703
    private var pendingCsv: String = ""
    private lateinit var root: LinearLayout
    private val bg=Color.rgb(11,18,32); private val panel=Color.rgb(22,32,51)
    private val white=Color.rgb(239,246,255); private val muted=Color.rgb(148,163,184)
    private val cyan=Color.rgb(56,189,248); private val green=Color.rgb(52,211,153); private val red=Color.rgb(251,113,133)
    private val fmt=NumberFormat.getIntegerInstance(Locale("ar","DZ"))
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun money(n:Long)=fmt.format(n)+" دج"
    private fun label(s:String,size:Float=15f,color:Int=white,bold:Boolean=false)=TextView(this).apply {
        text=s; textSize=size; setTextColor(color); gravity=Gravity.RIGHT
        if(bold)setTypeface(null,Typeface.BOLD)
    }
    private fun panel()=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(15),dp(13),dp(15),dp(13)); setBackgroundColor(this@MainActivity.panel) }
    private fun btn(s:String, f:()->Unit)=Button(this).apply { text=s; setOnClickListener{f()} }
    private fun gap(v:Int)=View(this).apply { layoutParams=LinearLayout.LayoutParams(1,dp(v)) }

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        db=DBHelper(this)
        authenticate()
    }

    private fun pinHash(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
    private fun authenticate() {
        val prefs = getSharedPreferences("security", MODE_PRIVATE)
        val saved = prefs.getString("pin_hash", null)
        val input = EditText(this).apply {
            hint = "أدخل 6 أرقام"
            inputType = 2
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
        }
        val title = if(saved == null) "إنشاء رمز حماية من 6 أرقام" else "أدخل رمز الحماية"
        val dialog = AlertDialog.Builder(this).setTitle(title).setMessage("احفظ الرمز جيداً؛ لا يمكن استرجاعه إذا نسيته.")
            .setView(input).setCancelable(false)
            .setPositiveButton(if(saved == null) "حفظ وفتح" else "فتح", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pin = input.text.toString()
                if(!pin.matches(Regex("\\d{6}"))) {
                    toast("يجب إدخال 6 أرقام بالضبط"); return@setOnClickListener
                }
                if(saved == null) {
                    prefs.edit().putString("pin_hash", pinHash(pin)).apply()
                    dialog.dismiss(); home()
                } else if(pinHash(pin) == saved) {
                    dialog.dismiss(); home()
                } else toast("الرمز غير صحيح")
            }
        }
        dialog.show()
    }

    private fun shell(title:String, subtitle:String="") : LinearLayout {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(20),dp(16),dp(12)); setBackgroundColor(bg) }
        val sc=ScrollView(this); val body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        sc.addView(body); root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        body.addView(label(title,27f,cyan,true))
        if(subtitle.isNotEmpty()) body.addView(label(subtitle,13f,muted))
        val nav=LinearLayout(this).apply { gravity=Gravity.CENTER; orientation=LinearLayout.HORIZONTAL }
        listOf("الرئيسية","الديون","الفواتير","الادخار","التقارير").forEachIndexed { i,s ->
            nav.addView(btn(s){ when(i){0->home();1->debtsPage();2->billsPage();3->savingsPage();else->reportsPage()} },
                LinearLayout.LayoutParams(0,-2,1f))
        }
        root.addView(nav); setContentView(root); return body
    }

    private fun home() {
        val body=shell("راتبي","إدارة راتبك ومصاريفك بالدينار الجزائري")
        val tx=db.transactions(); val salary=db.salary()
        val exp=tx.filter{it.type=="expense"}.sumOf{it.amount}
        val inc=tx.filter{it.type=="income"}.sumOf{it.amount}
        val balance=salary+inc-exp
        val c=panel()
        c.addView(label("الرصيد المتاح",14f,muted)); c.addView(label(money(balance),30f,green,true))
        c.addView(label("الراتب الأساسي: ${money(salary)}",14f))
        c.addView(label("المداخيل الإضافية: ${money(inc)}",13f,muted))
        c.addView(label("إجمالي المصاريف: ${money(exp)}",13f,muted))
        body.addView(c); body.addView(gap(10))
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        actions.addView(btn("تحديد الراتب"){salaryDialog()},LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(btn("＋ مصروف"){txDialog("expense")},LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(btn("＋ دخل"){txDialog("income")},LinearLayout.LayoutParams(0,-2,1f))
        body.addView(actions)
        val toolsRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        toolsRow.addView(btn("نسخ احتياطي"){backupDatabase()}, LinearLayout.LayoutParams(0,-2,1f))
        toolsRow.addView(btn("استرجاع"){restoreDatabase()}, LinearLayout.LayoutParams(0,-2,1f))
        toolsRow.addView(btn("تصدير Excel"){exportCsv()}, LinearLayout.LayoutParams(0,-2,1f))
        body.addView(toolsRow)
        body.addView(label("آخر العمليات",19f,white,true).apply{setPadding(0,dp(14),0,dp(7))})
        if(tx.isEmpty()) body.addView(label("لا توجد عمليات بعد. حدّد راتبك وسجّل أول مصروف.",14f,muted))
        tx.take(30).forEach { e ->
            val row=panel(); row.addView(label(e.title,15f,white,true))
            row.addView(label("${e.date}   ${if(e.type=="expense")"−" else "+"} ${money(e.amount)}",13f,if(e.type=="expense")red else green))
            row.addView(btn("حذف"){ confirm("حذف العملية؟"){db.deleteTx(e.id);home()} })
            body.addView(row); body.addView(gap(6))
        }
        body.addView(label("تُحفظ البيانات محلياً على هذا الهاتف.",12f,muted))
    }

    private fun salaryDialog() {
        val input=EditText(this).apply{hint="الراتب الشهري بالدينار";inputType=2;setText(if(db.salary()>0)db.salary().toString():"")}
        AlertDialog.Builder(this).setTitle("تحديد الراتب").setView(input)
            .setPositiveButton("حفظ"){_,_-> val n=input.text.toString().toLongOrNull(); if(n!=null&&n>=0){db.setSalary(n);home()}else toast("أدخل مبلغاً صحيحاً")}
            .setNegativeButton("إلغاء",null).show()
    }
    private fun txDialog(type:String) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),0)}
        val title=EditText(this).apply{hint=if(type=="expense")"سبب المصروف" else "مصدر الدخل"}
        val amount=EditText(this).apply{hint="المبلغ بالدينار";inputType=2}
        box.addView(title);box.addView(amount)
        AlertDialog.Builder(this).setTitle(if(type=="expense")"إضافة مصروف" else "إضافة دخل").setView(box)
            .setPositiveButton("حفظ"){_,_->val n=amount.text.toString().toLongOrNull();val t=title.text.toString().trim()
                if(n!=null&&n>0&&t.isNotEmpty()){db.addTx(t,n,type);home()}else toast("تحقق من الوصف والمبلغ")}
            .setNegativeButton("إلغاء",null).show()
    }
    private fun debtsPage() {
        val body=shell("الديون والسلف","سجّل ما عليك وما لك عند الآخرين")
        body.addView(btn("＋ إضافة دين أو سلفة"){debtDialog()})
        db.debts().forEach { d ->
            val c=panel(); c.addView(label(d.title,16f,white,true))
            c.addView(label("${if(d.status=="owe")"عليك" else "لك عنده"}: ${money(d.amount)}",14f,if(d.status=="owe")red else green))
            if(d.date.isNotEmpty())c.addView(label(d.date,12f,muted))
            c.addView(btn("حذف"){confirm("حذف السجل؟"){db.deleteDebt(d.id);debtsPage()}})
            body.addView(c);body.addView(gap(7))
        }
        if(db.debts().isEmpty())body.addView(label("لا توجد ديون مسجلة.",14f,muted))
    }
    private fun debtDialog() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),0)}
        val person=EditText(this).apply{hint="اسم الشخص"}
        val amount=EditText(this).apply{hint="المبلغ بالدينار";inputType=2}
        val note=EditText(this).apply{hint="ملاحظة (اختياري)"}
        val kind=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("عليّ دين","لي عند شخص"))}
        box.addView(person);box.addView(amount);box.addView(kind);box.addView(note)
        AlertDialog.Builder(this).setTitle("إضافة دين أو سلفة").setView(box)
            .setPositiveButton("حفظ"){_,_->val n=amount.text.toString().toLongOrNull();val p=person.text.toString().trim()
                if(n!=null&&n>0&&p.isNotEmpty()){db.addDebt(p,n,if(kind.selectedItemPosition==0)"owe" else "lent",note.text.toString());debtsPage()}else toast("أدخل الاسم والمبلغ")}
            .setNegativeButton("إلغاء",null).show()
    }
    private fun billsPage() {
        val body=shell("الفواتير الشهرية","تابع فواتيرك ومواعيد دفعها")
        body.addView(btn("＋ إضافة فاتورة"){billDialog()})
        db.bills().forEach { b ->
            val c=panel(); c.addView(label(b.title,16f,white,true));c.addView(label("${money(b.amount)}  •  تاريخ الاستحقاق: ${b.date}",14f,muted))
            c.addView(label(if(b.status=="paid")"مدفوعة" else "غير مدفوعة",13f,if(b.status=="paid")green else red,true))
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            row.addView(btn(if(b.status=="paid")"إلغاء الدفع" else "تحديد كمدفوعة"){db.toggleBill(b.id,b.status!="paid");billsPage()},LinearLayout.LayoutParams(0,-2,1f))
            row.addView(btn("حذف"){confirm("حذف الفاتورة؟"){db.deleteBill(b.id);billsPage()}},LinearLayout.LayoutParams(0,-2,1f))
            c.addView(row);body.addView(c);body.addView(gap(7))
        }
        if(db.bills().isEmpty())body.addView(label("لا توجد فواتير مسجلة.",14f,muted))
    }
    private fun billDialog() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),0)}
        val title=EditText(this).apply{hint="اسم الفاتورة (كهرباء، إنترنت...)"}
        val amount=EditText(this).apply{hint="المبلغ بالدينار";inputType=2}
        val due=EditText(this).apply{hint="تاريخ الاستحقاق (مثال 2026-12-05)"}
        box.addView(title);box.addView(amount);box.addView(due)
        AlertDialog.Builder(this).setTitle("إضافة فاتورة").setView(box)
            .setPositiveButton("حفظ"){_,_->val n=amount.text.toString().toLongOrNull();val t=title.text.toString().trim()
                if(n!=null&&n>0&&t.isNotEmpty()){db.addBill(t,n,due.text.toString());billsPage()}else toast("أدخل اسم الفاتورة والمبلغ")}
            .setNegativeButton("إلغاء",null).show()
    }
    private fun savingsPage() {
        val body=shell("الادخار","أنشئ أهدافاً وتابع تقدمك نحوها")
        body.addView(btn("＋ هدف ادخار جديد"){goalDialog()})
        db.goals().forEach { g ->
            val c=panel();val pct=if(g.amount>0)(100*g.extra/g.amount).coerceIn(0,100).toInt() else 0
            c.addView(label(g.title,16f,white,true));c.addView(label("${money(g.extra)} من ${money(g.amount)}  •  $pct%",14f,green))
            val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=pct}
            c.addView(bar)
            c.addView(btn("＋ إضافة مبلغ للادخار"){contributeDialog(g)})
            c.addView(btn("حذف الهدف"){confirm("حذف هدف الادخار؟"){db.deleteGoal(g.id);savingsPage()}})
            body.addView(c);body.addView(gap(7))
        }
        if(db.goals().isEmpty())body.addView(label("لا توجد أهداف ادخار بعد.",14f,muted))
    }
    private fun goalDialog() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),0)}
        val title=EditText(this).apply{hint="اسم الهدف (هاتف، سيارة...)"}
        val target=EditText(this).apply{hint="المبلغ المستهدف بالدينار";inputType=2}
        box.addView(title);box.addView(target)
        AlertDialog.Builder(this).setTitle("هدف ادخار جديد").setView(box)
            .setPositiveButton("إنشاء"){_,_->val n=target.text.toString().toLongOrNull();val t=title.text.toString().trim()
                if(n!=null&&n>0&&t.isNotEmpty()){db.addGoal(t,n);savingsPage()}else toast("أدخل اسم الهدف والمبلغ")}
            .setNegativeButton("إلغاء",null).show()
    }
    private fun contributeDialog(g:Record) {
        val input=EditText(this).apply{hint="المبلغ المضاف بالدينار";inputType=2}
        AlertDialog.Builder(this).setTitle("إضافة إلى ${g.title}").setView(input)
            .setPositiveButton("إضافة"){_,_->val n=input.text.toString().toLongOrNull()
                if(n!=null&&n>0){db.updateGoal(g.id,g.extra+n);savingsPage()}else toast("أدخل مبلغاً صحيحاً")}
            .setNegativeButton("إلغاء",null).show()
    }
    private fun reportsPage() {
        val body=shell("التقارير الشهرية","مقارنة الشهر الحالي بالشهر السابق")
        val current=db.monthTotals(0); val previous=db.monthTotals(-1)
        val c=panel()
        c.addView(label("الشهر الحالي",17f,cyan,true))
        c.addView(label("المصاريف: ${money(current.first)}",15f,red,true))
        c.addView(label("المداخيل الإضافية: ${money(current.second)}",15f,green,true))
        c.addView(label("الصافي: ${money(current.second-current.first)}",14f,white))
        c.addView(gap(12))
        c.addView(label("الشهر السابق",17f,cyan,true))
        c.addView(label("المصاريف: ${money(previous.first)}",15f,red,true))
        c.addView(label("المداخيل الإضافية: ${money(previous.second)}",15f,green,true))
        c.addView(label("الصافي: ${money(previous.second-previous.first)}",14f,white))
        body.addView(c)
        body.addView(gap(10))
        val diff=current.first-previous.first
        val msg=when { diff>0 -> "زادت المصاريف بمقدار ${money(diff)} مقارنة بالشهر السابق."
            diff<0 -> "انخفضت المصاريف بمقدار ${money(-diff)} مقارنة بالشهر السابق."
            else -> "مصاريفك مساوية للشهر السابق." }
        body.addView(label(msg,14f,if(diff>0)red else green,true))
        body.addView(gap(8))
        body.addView(btn("تصدير تقرير CSV متوافق مع Excel"){exportCsv()})
        body.addView(label("ملاحظة: التقارير تعتمد على العمليات التي سجلتها يدوياً، ولا تشمل الراتب الأساسي ضمن المداخيل الإضافية.",12f,muted))
    }

    private fun backupDatabase() {
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="application/octet-stream"
            putExtra(Intent.EXTRA_TITLE,"ratibi-backup.db")
        }
        startActivityForResult(intent,CREATE_BACKUP)
    }
    private fun restoreDatabase() {
        AlertDialog.Builder(this).setTitle("استرجاع نسخة احتياطية")
            .setMessage("سيتم استبدال بيانات راتبي الحالية بالنسخة المختارة. يُفضّل إنشاء نسخة احتياطية أولاً.")
            .setPositiveButton("اختيار ملف"){_,_->
                val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type="*/*"
                }
                startActivityForResult(intent,RESTORE_BACKUP)
            }.setNegativeButton("إلغاء",null).show()
    }
    private fun exportCsv() {
        val rows=db.transactions()
        val sb=StringBuilder("\uFEFFالتاريخ,النوع,الوصف,المبلغ بالدينار\\n")
        rows.reversed().forEach { e ->
            val type=if(e.type=="expense")"مصروف" else "دخل"
            val safe=e.title.replace("\\\"", "\\\"\\\"")
            sb.append("\"${e.date}\",\"${type}\",\"${safe}\",${e.amount}\\n")
        }
        pendingCsv=sb.toString()
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="text/csv"
            putExtra(Intent.EXTRA_TITLE,"ratibi-report.csv")
        }
        startActivityForResult(intent,EXPORT_CSV)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data?.data==null) return
        val uri=data.data!!
        try {
            when(requestCode) {
                CREATE_BACKUP -> {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        val dbFile=getDatabasePath("ratibi.db")
                        dbFile.inputStream().use { it.copyTo(out) }
                    }
                    toast("تم إنشاء النسخة الاحتياطية")
                }
                RESTORE_BACKUP -> {
                    val dbFile=getDatabasePath("ratibi.db")
                    db.close()
                    contentResolver.openInputStream(uri)?.use { input ->
                        dbFile.outputStream().use { output -> input.copyTo(output) }
                    }
                    db=DBHelper(this)
                    toast("تم الاسترجاع؛ سيتم تحديث الشاشة")
                    home()
                }
                EXPORT_CSV -> {
                    contentResolver.openOutputStream(uri)?.use { it.write(pendingCsv.toByteArray(Charsets.UTF_8)) }
                    toast("تم تصدير التقرير؛ افتحه ببرنامج Excel")
                }
            }
        } catch(e:Exception) { toast("تعذر إتمام العملية: ${e.localizedMessage ?: "خطأ"}") }
    }

    private fun confirm(msg:String, action:()->Unit) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("تأكيد"){_,_->action()}.setNegativeButton("إلغاء",null).show()
    }
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
}
